#### Cute Yellow Blob Resurrector

This module is yet another cute blob resurrenctor.

#### NOTICE

* You should use latest Magisk Manager to install this module. If you meet any problem under installation from Magisk Manager, please try to install it from recovery.

#### Credit & Support

* This script originally written by - AndroPlus (https://androplus.org)
* Author of Koruri - lindwurm (https://github.com/lindwurm)

## Change log

#### v0.0
* First Release

#### v0.1
* Adoption to New Magisk Template
