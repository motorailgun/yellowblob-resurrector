## Components

All fonts are on [Google i18n Github](https://github.com/googlei18n/noto-emoji) and licensed with **Apache License** See[LICENSE](LICENSE)
And the module I built on is [AndroPlus's Github](https://github.com/Magisk-Modules-Repo/font-koruri-n)

## License

This Module is licensed under **Apache License v2.0**. See [LICENSE](LICENSE).

## Author

### motorailgun

- [@motorailgun@mstdn.maud.io](https://mstdn.maud.io/motorailgun) : Fediverse(Mastodon)
- [@motorailgun@twitter.com](https://twitter.com/motorailgun) : Twitter

### AndroPlus
- [AndroPlus](https://androplus.org)
- [@AndroPlus_org@twitter.com](https://twitter.com/AndroPlus_org)
- [@AndroPlus@mstdn.maud.io](https://mstdn.maud.io/@AndroPlus)
